<script>
 var myArray = [
  'https://www.sab.com/',

 ];
 var rand = myArray[Math.floor(Math.random() * myArray.length)];
 window.location.assign(rand);
</script>